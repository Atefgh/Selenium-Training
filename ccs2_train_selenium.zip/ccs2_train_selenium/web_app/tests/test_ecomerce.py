from unicodedata import name
from xml.sax.xmlreader import Locator
from web_app.MyLib import SeleniumLib
import time
from selenium.webdriver.common.by import By
import pytest

class TestSaucedemo:

    # def setup_method(self):
    #     self.app = SeleniumLib()
    #     self._driver = self.app.config_driver('ff', 5000)

    # def teardown_method(self):
    #     self.app.close_driver()

    def setup_class(self):
        self.app = SeleniumLib()
        self._driver = self.app.config_driver('ff', 5000)

    def teardown_class(self): 
        self.app.close_driver()

    @pytest.mark.order(1)
    @pytest.mark.dependency(name="check")
    def test_login(self):
        url = "https://www.saucedemo.com/"
        time.sleep(4)
        self.app.open_url(url)
        time.sleep(1)
        self.app.maximize_window()

        locator = '//input[@id="user-name"]'
        elm = self._driver.find_element(By.XPATH, locator)
        elm.send_keys('standard_user')

        locator = '//input[@id="password"]'
        elm = self._driver.find_element(By.XPATH, locator)
        elm.send_keys('secret_sauce')
        
        locator = '//input[@id="login-button"]'
        elm = self._driver.find_element(By.XPATH, locator)
        elm.click()
        time.sleep(2)
        verdict = None
        try:
            locator = '//span[@class="title"]'
            elm = self._driver.find_element(By.XPATH, locator)
            txt = elm.text
            if txt.strip().lower() == 'products' :
                verdict = True
        except:
            verdict = False

        assert verdict, "Login Failed"

    @pytest.mark.order(2)
    @pytest.mark.dependency(depends=["check"])
    def test_selection(self):
        locator = '//div[@class="inventory_item"]'
        elms = self._driver.find_elements(By.XPATH, locator)
        iter = 0
        assert len(elms) > 0
        for element in elms:
            iter += 1
            locator = '//button[@class="btn btn_primary btn_small btn_inventory"]'
            elm = self._driver.find_element(By.XPATH, locator)
            elm.click()
            locator = '//div[@class="inventory_item_name"]'
            elm = self._driver.find_element(By.XPATH, locator)
            print(elm.text)
            if iter == 2:
                break
