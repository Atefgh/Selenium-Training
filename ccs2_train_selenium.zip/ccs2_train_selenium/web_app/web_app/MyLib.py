from http import server
from lib2to3.pgen2 import driver
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
# class MyLib:
#     def __init__(self):
#          pass

#Config driver = browser(firfox, chrome...)
# server = "/home/aghanmi/driver/geckodriver"

# # driver = webdriver.Firefox(executable_path=server)
# port = 5000
# browser_options = webdriver.FirefoxOptions()
# driver = webdriver.Remote(
#     command_executor = f"127.0.0.1:{port}",
#     options = browser_options
#     )

# url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login "
# driver.get(url)
# time.sleep(1)
# driver.maximize_window()

# locator = '//input[@name="usernamekk"]'
# elm = driver.find_element(By.XPATH, locator)
# elm.send_keys('Admin')

# loc = '//input[@name="password"]'
# element = driver.find_element(By.XPATH, loc)
# element.send_keys('admin123')

# locator = '//button[@type="submit"]'
# elm = driver.find_element(By.XPATH, locator)
# elm.click() 

# time.sleep(3)
# driver.close()

class SeleniumLib():
    def __init__(self):
        self.firefox_browser = ['ff', 'firefox']
        self.chrome_browser = ['gc', 'chrome', 'google']

    def config_driver(self, browser, port):
        browser_options = None
        if browser.lower() in self.firefox_browser:
            browser_options = webdriver.FirefoxOptions()

        elif browser.lower() in self.chrome_browser():
            browser_options = webdriver.ChromeOptions()

        else:
            raise ValueError(f'[{browser}] not supported; supported values={self.firefox_browser}, {self.chrome_browser}')
        
        self.driver = webdriver.Remote(
            command_executor = f"127.0.0.1:{port}",
            options = browser_options
        )
        return self.driver

    def close_driver(self):
        time.sleep(2)
        self.driver.close()

    def open_url(self, url):
        self.driver.get(url)
    
    def maximize_window(self):
        self.driver.maximize_window()